/*
 * Author: Jonatan Schroeder
 * Updated: March 2022
 *
 * This code may not be used without written consent of the authors.
 */

package ca.yorku.rtsp.client.net;

import ca.yorku.rtsp.client.exception.RTSPException;
import ca.yorku.rtsp.client.model.Frame;
import ca.yorku.rtsp.client.model.Session;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;

/**
 * This class represents a connection with an RTSP server.
 */
public class RTSPConnection {

	private static final int BUFFER_LENGTH = 0x10000;

	private Session session;
	// TCP/RTSP Socket
	Socket tcpSocket = null;
	PrintWriter out = null; // Write to the socket
	BufferedReader in = null; // Read from the socket
	// Session Number and cSeq Number
	int sessionNum = 0;
	int cSeq = 1;
	// UDP/RTP Socket
	static DatagramSocket udpSocket = null;
	DatagramPacket udpPacket = null;
	// Frame number
	static short frameNumber = 1;
	// The thread
	static RTPReceivingThread thread = null;
	static boolean isPaused = false;
	static int prev = 0;
	static Frame prevFrame = null;
	static boolean stopThread = false;

	/**
	 * Establishes a new connection with an RTSP server. No message is sent at this
	 * point, and no stream is set up.
	 *
	 * @param session The Session object to be used for connectivity with the UI.
	 * @param server  The hostname or IP address of the server.
	 * @param port    The TCP port number where the server is listening to.
	 * @throws RTSPException If the connection couldn't be accepted, such as if the
	 *                       host name or port number are invalid or there is no
	 *                       connectivity.
	 */
	public RTSPConnection(Session session, String server, int port) throws RTSPException {

		this.session = session;
		try {
			// Creating the TCP socket
			tcpSocket = new Socket(server, port);
			out = new PrintWriter(tcpSocket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(tcpSocket.getInputStream()));

		} catch (UnknownHostException e) {
			throw new RTSPException("Unknown Server/Host");
		} catch (IOException e) {
			throw new RTSPException("Unknown Port number");
		}
	}

	/**
	 * Sends a SETUP request to the server. This method is responsible for sending
	 * the SETUP request, receiving the response and retrieving the session
	 * identification to be used in future messages. It is also responsible for
	 * establishing an RTP datagram socket to be used for data transmission by the
	 * server. The datagram socket should be created with a random UDP port number,
	 * and the port number used in that connection has to be sent to the RTSP server
	 * for setup. This datagram socket should also be defined to timeout after 1
	 * second if no packet is received.
	 *
	 * @param videoName The name of the video to be setup.
	 * @throws RTSPException If there was an error sending or receiving the RTSP
	 *                       data, or if the RTP socket could not be created, or if
	 *                       the server did not return a successful response.
	 */
	public synchronized void setup(String videoName) throws RTSPException {
		// Reset our values
		frameNumber = 1;
		prevFrame = null;

		stopThread = false;
		try {
			udpSocket = new DatagramSocket();
			udpSocket.setSoTimeout(1000);
		} catch (SocketException e) {
			throw new RTSPException("Socket Timed out");
		}
		// Creating the datagram Packet
		ByteBuffer buf = ByteBuffer.allocate(BUFFER_LENGTH);
		udpPacket = new DatagramPacket(buf.array(), BUFFER_LENGTH);

		// Sending the Request
		System.out.println("\nSETUP " + videoName + " RTSP/1.0\n" + "CSeq: " + cSeq + "\n"
				+ "Transport: RTP/UDP; client_port= " + udpSocket.getLocalPort() + "\r\n");
		out.println("SETUP " + videoName + " RTSP/1.0\n" + "CSeq: " + cSeq + "\n" + "Transport: RTP/UDP; client_port= "
				+ udpSocket.getLocalPort() + "\r\n");
		try {
			RTSPResponse response = this.readRTSPResponse();
		} catch (IOException e) {
			throw new RTSPException("SETUP: IOException");
		} catch (RTSPException e) {
			throw new RTSPException("SETUP: RTSPException");
		}
	}

	/**
	 * Sends a PLAY request to the server. This method is responsible for sending
	 * the request, receiving the response and, in case of a successful response,
	 * starting a separate thread responsible for receiving RTP packets with frames.
	 *
	 * @throws RTSPException If there was an error sending or receiving the RTSP
	 *                       data, or if the server did not return a successful
	 *                       response.
	 */
	public synchronized void play() throws RTSPException {
		stopThread = false;
		thread = new RTPReceivingThread();
		if (prevFrame == null) {
			thread.start();
		}
		isPaused = false;
		out.println("PLAY " + session.getVideoName() + " RTSP/1.0\n" + "CSeq: " + this.cSeq + "\n" + "Session: "
				+ this.sessionNum + "\r\n");
		System.out.println("\nPLAY " + session.getVideoName() + " RTSP/1.0\n" + "CSeq: " + this.cSeq + "\n"
				+ "Session: " + this.sessionNum + "\r\n");
		RTSPResponse response;
		try {
			response = this.readRTSPResponse();
		} catch (IOException e) {
			throw new RTSPException("PLAY: IOException");
		} catch (RTSPException e) {
			throw new RTSPException("PLAY: RTSPException");
		}

	}

	private class RTPReceivingThread extends Thread {
		/**
		 * Continuously receives RTP packets until the thread is cancelled. Each packet
		 * received from the datagram socket is assumed to be no larger than
		 * BUFFER_LENGTH bytes. This data is then parsed into a Frame object (using the
		 * parseRTPPacket method) and the method session.processReceivedFrame is called
		 * with the resulting packet. The receiving process should be configured to
		 * timeout if no RTP packet is received after two seconds.
		 */
		@Override
		public void run() {
			while (true && !udpSocket.isClosed()) {
				while (!isPaused) {
					try {
						udpSocket.setSoTimeout(2000);
						session.processReceivedFrame(RTSPConnection.parseRTPPacket(udpPacket));
					} catch (SocketException e) {
						System.out.println("RUN: Socket timed out");
						return;
					}
				}
				if (isPaused && !stopThread) {
					try {
						udpSocket.setSoTimeout(Integer.MAX_VALUE);
						session.processReceivedFrame(RTSPConnection.parseRTPPacket(udpPacket));
					} catch (SocketException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}

	/**
	 * Sends a PAUSE request to the server. This method is responsible for sending
	 * the request, receiving the response and, in case of a successful response,
	 * stopping the thread responsible for receiving RTP packets with frames.
	 *
	 * @throws RTSPException If there was an error sending or receiving the RTSP
	 *                       data, or if the server did not return a successful
	 *                       response.
	 */
	public synchronized void pause() throws RTSPException {

		RTSPResponse response;
		stopThread = false;
		out.println("PAUSE " + session.getVideoName() + " RTSP/1.0\n" + "CSeq: " + this.cSeq + "\n" + "Session: "
				+ this.sessionNum + "\r\n");

		System.out.println("\nPAUSE " + session.getVideoName() + " RTSP/1.0\n" + "CSeq: " + this.cSeq + "\n"
				+ "Session: " + this.sessionNum + "\r\n");
		try {
			response = this.readRTSPResponse();

			isPaused = true;
		} catch (IOException e) {
			throw new RTSPException("PAUSE: IOException");
		} catch (RTSPException e) {
			throw new RTSPException("PAUSE: RTSPException");
		}
	}

	/**
	 * Sends a TEARDOWN request to the server. This method is responsible for
	 * sending the request, receiving the response and, in case of a successful
	 * response, closing the RTP socket. This method does not close the RTSP
	 * connection, and a further SETUP in the same connection should be accepted.
	 * Also this method can be called both for a paused and for a playing stream, so
	 * the thread responsible for receiving RTP packets will also be cancelled.
	 *
	 * @throws RTSPException If there was an error sending or receiving the RTSP
	 *                       data, or if the server did not return a successful
	 *                       response.
	 */
	public synchronized void teardown() throws RTSPException {
		RTSPResponse response;
		// Reset our values
		frameNumber = 1;
		prevFrame = null;

		stopThread = true;
		out.println("TEARDOWN " + session.getVideoName() + " RTSP/1.0\n" + "CSeq: " + this.cSeq + "\n" + "Session: "
				+ this.sessionNum + "\r\n");

		System.out.println("\nTEARDOWN " + session.getVideoName() + " RTSP/1.0\n" + "CSeq: " + this.cSeq + "\n"
				+ "Session: " + this.sessionNum + "\r\n");
		try {
			response = this.readRTSPResponse();
			isPaused = true;
		} catch (IOException e) {
			throw new RTSPException("TEARDOWN: IOException");
		} catch (RTSPException e) {
			throw new RTSPException("TEARDOWN: RTSPException");
		}
		udpSocket.close();
	}

	/**
	 * Closes the connection with the RTSP server. This method should also close any
	 * open resource associated to this connection, such as the RTP connection, if
	 * it is still open.
	 */
	public synchronized void closeConnection() {
		frameNumber = 1;
		prevFrame = null;
		stopThread = true;
		if (udpSocket != null) {
			udpSocket.close();
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			out.close();
		}
		try {
			tcpSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Parses an RTP packet into a Frame object.
	 *
	 * @param packet the byte representation of a frame, corresponding to the RTP
	 *               packet.
	 * @return A Frame object.
	 */
	public static Frame parseRTPPacket(DatagramPacket packet) {
		Frame result = null;
		try {
			if (!isPaused) {
				udpSocket.receive(packet);
				ByteBuffer buf = ByteBuffer.allocate(BUFFER_LENGTH);
				buf.put(packet.getData());
				result = new Frame((byte) 26, false, frameNumber, frameNumber * 40, buf.array(), 12,
						packet.getLength() - 12);
				frameNumber++;
				prevFrame = result;
			} else {
				result = prevFrame;
			}
		} catch (Exception e) {
			System.out.println("parseRTPPacket: Paused");
		}

		return result;

	}

	/**
	 * Reads and parses an RTSP response from the socket's input.
	 *
	 * @return An RTSPResponse object if the response was read completely, or null
	 *         if the end of the stream was reached.
	 * @throws IOException   In case of an I/O error, such as loss of connectivity.
	 * @throws RTSPException If the response doesn't match the expected format.
	 */
	public RTSPResponse readRTSPResponse() throws IOException, RTSPException {
		cSeq++;
		String strOut = "";
		int responseCode = 0;
		String responseVersion = "";
		String responseMessage = "";
		RTSPResponse result = null;
		try {
			while ((strOut = in.readLine()) != null&& !strOut.equals("") && !strOut.equals("\n") ) {
				System.out.println(strOut);
				// Extract the response Code, RTSP version and message
				if (strOut.contains("200")) {
					responseVersion = strOut.split(" ")[0];
					responseCode = Integer.valueOf(strOut.split(" ")[1]);
					responseMessage = strOut.split(" ")[2];
				}
				if (strOut.contains("Session")) { // Get the session number, it exists after ": ", when found set
					this.sessionNum = Integer.valueOf(strOut.split(" ")[1]);
				}
			}
			if (responseCode != 200) {
				throw new RTSPException("Response was not 200");
			}
			result = new RTSPResponse(responseVersion, responseCode, responseMessage);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (responseCode == 0 || responseVersion.equals("") || responseMessage.equals("")) {
			throw new RTSPException("Error code: " + responseCode);
		}
		return result; // Replace with a proper RTSPResponse
	}

}
